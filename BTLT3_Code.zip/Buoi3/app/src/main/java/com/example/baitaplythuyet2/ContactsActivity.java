package com.example.baitaplythuyet2;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;



import java.util.ArrayList;
import java.util.List;

public class ContactsActivity extends AppCompatActivity {

    private ContactDatabaseHandler cdb;
    private ArrayAdapter<String> adapter;
    private final List<Contact> contacts = new ArrayList<>();
    private final List<String> rows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        ListView lv = findViewById(R.id.lv_contacts);
        Button btnAdd = findViewById(R.id.btn_add);
        cdb = new ContactDatabaseHandler(this);

        // thêm dữ liệu mẫu nếu trống
        if (cdb.getAllContacts().isEmpty()) {
            cdb.addContact(new Contact("Ravi", "9100000000"));
            cdb.addContact(new Contact("Srinivas", "9199999999"));
            cdb.addContact(new Contact("Tommy", "9522222222"));
            cdb.addContact(new Contact("Karthik", "9533333333"));
        }

        loadData();

        adapter = new ArrayAdapter<>(this, R.layout.item_contact, rows);


        // Thêm mới
        btnAdd.setOnClickListener(v -> showAddDialog());

        // Chạm 1 lần: sửa; Nhấn giữ: xoá
        lv.setOnItemClickListener((p, view, pos, id) -> showEditDialog(pos));
        lv.setOnItemLongClickListener((p, view, pos, id) -> {
            int contactId = contacts.get(pos).getId();
            if (cdb.deleteContact(contactId) > 0) {
                loadData();
                adapter.notifyDataSetChanged();
            }
            return true;
        });
    }

    private void loadData() {
        contacts.clear();
        rows.clear();
        contacts.addAll(cdb.getAllContacts());
        for (Contact c : contacts) {
            rows.add(c.getName() + " — " + c.getPhoneNumber());
        }
    }

    private void showAddDialog() {
        final EditText etName = new EditText(this);
        etName.setHint("Tên");
        final EditText etPhone = new EditText(this);
        etPhone.setHint("Số điện thoại");
        etPhone.setInputType(InputType.TYPE_CLASS_PHONE);

        LinearLayoutV ll = new LinearLayoutV(this, etName, etPhone);

        new AlertDialog.Builder(this)
                .setTitle("Thêm liên hệ")
                .setView(ll.view)
                .setPositiveButton("Lưu", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    String ph = etPhone.getText().toString().trim();
                    if (!name.isEmpty()) {
                        cdb.addContact(new Contact(name, ph));
                        loadData();
                        adapter.notifyDataSetChanged();
                    }
                })
                .setNegativeButton("Huỷ", null)
                .show();
    }

    private void showEditDialog(int pos) {
        Contact cur = contacts.get(pos);

        final EditText etName = new EditText(this);
        etName.setText(cur.getName());
        final EditText etPhone = new EditText(this);
        etPhone.setInputType(InputType.TYPE_CLASS_PHONE);
        etPhone.setText(cur.getPhoneNumber());

        LinearLayoutV ll = new LinearLayoutV(this, etName, etPhone);

        new AlertDialog.Builder(this)
                .setTitle("Sửa liên hệ")
                .setView(ll.view)
                .setPositiveButton("Cập nhật", (d, w) -> {
                    cur.setName(etName.getText().toString().trim());
                    cur.setPhoneNumber(etPhone.getText().toString().trim());
                    cdb.updateContact(cur);
                    loadData();
                    adapter.notifyDataSetChanged();
                })
                .setNeutralButton("Xoá", (d, w) -> {
                    cdb.deleteContact(cur.getId());
                    loadData();
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Đóng", null)
                .show();
    }

    /** helper nhỏ để dựng layout dọc nhanh cho dialog */
    private static class LinearLayoutV {
        android.widget.LinearLayout view;
        LinearLayoutV(android.content.Context ctx, android.view.View... children) {
            view = new android.widget.LinearLayout(ctx);
            view.setOrientation(android.widget.LinearLayout.VERTICAL);
            int p = (int) (ctx.getResources().getDisplayMetrics().density * 16);
            view.setPadding(p, p, p, p);
            for (android.view.View v : children) {
                android.widget.LinearLayout.LayoutParams lp =
                        new android.widget.LinearLayout.LayoutParams(
                                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.topMargin = (int) (ctx.getResources().getDisplayMetrics().density * 8);
                if (v instanceof EditText) ((EditText) v).setGravity(Gravity.START);
                view.addView(v, lp);
            }
        }
    }
}
