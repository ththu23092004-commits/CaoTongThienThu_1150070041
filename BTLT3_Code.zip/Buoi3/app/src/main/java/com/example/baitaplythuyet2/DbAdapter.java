package com.example.baitaplythuyet2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DbAdapter {
    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";

    private final Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private static final String TABLE = "users";

    public DbAdapter(Context ctx) {
        this.context = ctx.getApplicationContext();
    }

    public DbAdapter open() {
        if (dbHelper == null) dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (dbHelper != null) dbHelper.close();
    }

    public long createUser(String name) {
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        return db.insert(TABLE, null, values);
    }

    public boolean deleteUser(long id) {
        return db.delete(TABLE, KEY_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteAllUsers() {
        return db.delete(TABLE, null, null) > 0;
    }

    public Cursor getAllUsers() {
        // trả về _id, name để hiển thị
        return db.query(TABLE, new String[]{KEY_ID, KEY_NAME},
                null, null, null, null, KEY_ID + " ASC");
    }

    public int getUsersCount() {
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM " + TABLE, null);
        try {
            return c.moveToFirst() ? c.getInt(0) : 0;
        } finally {
            c.close();
        }
    }
}
