package com.example.baitaplythuyet2;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DbAdapter dbAdapter;
    private ArrayAdapter<String> adapter;
    private final List<String> users = new ArrayList<>();
    private final List<Long> ids = new ArrayList<>(); // map theo vị trí hiển thị

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lvUser = findViewById(R.id.lv_user);

        dbAdapter = new DbAdapter(this).open();

        // Chèn demo nếu bảng đang trống (tránh chèn trùng mỗi lần mở app)
        if (dbAdapter.getUsersCount() == 0) {
            for (int i = 0; i < 10; i++) {
                dbAdapter.createUser("Nguyễn Văn An " + i);
            }
        }

        loadData();

        // lưu ý: item_user có TextView id tv_user → dùng constructor có textViewId
        adapter = new ArrayAdapter<>(this, R.layout.item_user, R.id.tv_user, users);
        lvUser.setAdapter(adapter);

        // Nhấn giữ 1 item để xóa user tương ứng
        lvUser.setOnItemLongClickListener((parent, view, position, id) -> {
            long userId = ids.get(position);
            if (dbAdapter.deleteUser(userId)) {
                users.remove(position);
                ids.remove(position);
                adapter.notifyDataSetChanged();
            }
            return true;
        });
    }

    private void loadData() {
        users.clear();
        ids.clear();
        Cursor c = dbAdapter.getAllUsers();
        try {
            int colId = c.getColumnIndexOrThrow(DbAdapter.KEY_ID);
            int colName = c.getColumnIndexOrThrow(DbAdapter.KEY_NAME);
            while (c.moveToNext()) {
                ids.add(c.getLong(colId));
                users.add(c.getString(colName));
            }
        } finally {
            c.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbAdapter.close();
    }
}
