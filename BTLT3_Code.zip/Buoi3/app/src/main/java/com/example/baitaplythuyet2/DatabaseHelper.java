package com.example.baitaplythuyet2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Tên file CSDL và phiên bản
    public static final String DB_NAME = "Database_Demo.db";
    public static final int DB_VERSION = 1;

    // Lệnh tạo bảng (viết 1 dòng hoặc nối chuỗi, không xuống dòng bên trong dấu ")
    private static final String SQL_CREATE_USERS =
            "CREATE TABLE IF NOT EXISTS users (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT NOT NULL" +
                    ")";

    public DatabaseHelper(Context context) {
        // Không cần truyền name/factory/version ở ngoài; quản lý tập trung tại đây
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tạo bảng lần đầu
        db.execSQL(SQL_CREATE_USERS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Cách đơn giản cho lab: drop & create lại (sẽ mất dữ liệu cũ)
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}
