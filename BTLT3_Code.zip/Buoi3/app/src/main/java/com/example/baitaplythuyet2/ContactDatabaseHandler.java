package com.example.baitaplythuyet2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ContactDatabaseHandler extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "contactsManager.db";
    private static final String TABLE = "contacts";

    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_PH_NO = "phone_number";

    public ContactDatabaseHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        String CREATE =
                "CREATE TABLE IF NOT EXISTS " + TABLE + " (" +
                        KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        KEY_NAME + " TEXT, " +
                        KEY_PH_NO + " TEXT)";
        db.execSQL(CREATE);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    // CREATE
    public long addContact(Contact c) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(KEY_NAME, c.getName());
        v.put(KEY_PH_NO, c.getPhoneNumber());
        return db.insert(TABLE, null, v);
    }

    // READ one
    public Contact getContact(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cur = db.query(TABLE, new String[]{KEY_ID, KEY_NAME, KEY_PH_NO},
                KEY_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);
        try {
            if (cur.moveToFirst()) {
                return new Contact(
                        cur.getInt(cur.getColumnIndexOrThrow(KEY_ID)),
                        cur.getString(cur.getColumnIndexOrThrow(KEY_NAME)),
                        cur.getString(cur.getColumnIndexOrThrow(KEY_PH_NO)));
            }
            return null;
        } finally { cur.close(); }
    }

    // READ all
    public List<Contact> getAllContacts() {
        List<Contact> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cur = db.query(TABLE, new String[]{KEY_ID, KEY_NAME, KEY_PH_NO},
                null, null, null, null, KEY_NAME + " ASC");
        try {
            int iId = cur.getColumnIndexOrThrow(KEY_ID);
            int iName = cur.getColumnIndexOrThrow(KEY_NAME);
            int iPhone = cur.getColumnIndexOrThrow(KEY_PH_NO);
            while (cur.moveToNext()) {
                list.add(new Contact(cur.getInt(iId), cur.getString(iName), cur.getString(iPhone)));
            }
        } finally { cur.close(); }
        return list;
    }

    // UPDATE
    public int updateContact(Contact c) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(KEY_NAME, c.getName());
        v.put(KEY_PH_NO, c.getPhoneNumber());
        return db.update(TABLE, v, KEY_ID + "=?", new String[]{ String.valueOf(c.getId()) });
    }

    // DELETE
    public int deleteContact(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE, KEY_ID + "=?", new String[]{ String.valueOf(id) });
    }
}
